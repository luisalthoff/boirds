timestamp=$(date "+%Y-%m-%d %H:%M:%S")
msg="commit ($timestamp)"
git status
git add .
git commit -m "($msg)"
git push